import mongoose from "mongoose"


const userSchema = mongoose.Schema({

    category:{type:String,require:true},
    sub_category:{type:String,require:true},
    title:{type:String,require:true},
    description:{type:String},
    price:{type:Number,require:true},
    dis:{type:Number,require:true},
    cp:{type:Number,require:true},
    rating:{type:Number,require:true},
    rating_count:{type:Number,require:true},
});


const cartdata=mongoose.Schema({
    username:{type:String,require:true},
    cart: [userSchema]
})

const CartSchema=mongoose.model("CartSchema",cartdata)