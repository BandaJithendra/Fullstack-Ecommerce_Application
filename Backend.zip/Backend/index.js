import express from 'express'
import dotenv from 'dotenv'
import mongoose from 'mongoose'
// import signUpRoute from './routers/signUpRoute.js'
import signUpRoute from './routers/signupRoute.js'
import cors from 'cors'
import LoginRouter from './routers/loginRouter.js'
import dashbordRoute from './routers/dashboardRouter.js'

dotenv.config()

const app=express()
app.use(express.json())
app.use(cors())

const port=process.env.port || 3000
const uri=process.env.MONGO_URL

try{
    mongoose.connect(uri).then(console.log("Connected...."))
}catch(err){
    console.log("Error: ",err);
}

app.use(dashbordRoute)

app.use(signUpRoute)
app.use(LoginRouter)

app.listen(port,(req,res)=>{
    console.log("Server is on port ",port);
})












