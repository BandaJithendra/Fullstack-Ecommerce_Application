import express from 'express'
import { dashboardContoller } from '../controllers/dashboardController.js'

const dashbordRoute=express.Router()

dashbordRoute.get('/',dashboardContoller)


export default dashbordRoute