import React from 'react'
import Carousuel from './Carousuel'
import Header from  './Header'
import Brands from './Brands'
import ClothingSection from './ClothingSection'
import Category from '../newComponents/Category'


const Home = () => {
  return (
    <div>
        <Header/>
        <Brands/>
        <Carousuel/>
        {/* <ClothingSection/> */}
        <Category/>

    </div>
  )
}

export default Home