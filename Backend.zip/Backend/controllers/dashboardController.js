import dotenv from 'dotenv'
import jwt from 'jsonwebtoken'

dotenv.config()
const SECRET_KEY=process.env.SECRET_KEY

export const dashboardContoller=async (req,res)=>{

    const token = req.headers.authorization?.split(" ")[1]
    if(!token){
        return res.status(403).json({message: "No token generated"})
    }
    console.log(token)
    try{
        const decode = jwt.verify(token,SECRET_KEY)
        return res.status(200).json({message:"Success",user:decode.email})
    }catch(err){
        res.status(403).json({message:"Invalid token"})
    }

}












